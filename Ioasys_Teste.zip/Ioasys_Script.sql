/****** Object:  Database [dbIoasys]    Script Date: 18/11/2019 06:02:58 ******/
CREATE DATABASE [dbIoasys]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'dbIoasys', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\dbIoasys.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'dbIoasys_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\dbIoasys_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [dbIoasys].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [dbIoasys] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [dbIoasys] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [dbIoasys] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [dbIoasys] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [dbIoasys] SET ARITHABORT OFF 
GO

ALTER DATABASE [dbIoasys] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [dbIoasys] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [dbIoasys] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [dbIoasys] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [dbIoasys] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [dbIoasys] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [dbIoasys] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [dbIoasys] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [dbIoasys] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [dbIoasys] SET  DISABLE_BROKER 
GO

ALTER DATABASE [dbIoasys] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [dbIoasys] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [dbIoasys] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [dbIoasys] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [dbIoasys] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [dbIoasys] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [dbIoasys] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [dbIoasys] SET RECOVERY SIMPLE 
GO

ALTER DATABASE [dbIoasys] SET  MULTI_USER 
GO

ALTER DATABASE [dbIoasys] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [dbIoasys] SET DB_CHAINING OFF 
GO

ALTER DATABASE [dbIoasys] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO

ALTER DATABASE [dbIoasys] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO

ALTER DATABASE [dbIoasys] SET DELAYED_DURABILITY = DISABLED 
GO

ALTER DATABASE [dbIoasys] SET QUERY_STORE = OFF
GO

ALTER DATABASE [dbIoasys] SET  READ_WRITE 
GO




-- ****************************************************************************************************
CREATE TABLE [dbo].[Collections](
	[Id] [nvarchar](36) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](50) NULL,
	[TimeStamp] [bigint] NOT NULL,
	[Owner] [int] NOT NULL,
	[Public] [bit] NOT NULL,
 CONSTRAINT [PK_Collections] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- ****************************************************************************************************
CREATE TABLE [dbo].[Folders](
	[Id] [nvarchar](36) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](50) NULL,
	[Owner] [int] NOT NULL,
	[CollectionId] [nvarchar](36) NOT NULL,
 CONSTRAINT [PK_Folders] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Folders]  WITH CHECK ADD  CONSTRAINT [FK_Folders_Collections] FOREIGN KEY([CollectionId])
REFERENCES [dbo].[Collections] ([Id])
GO

ALTER TABLE [dbo].[Folders] CHECK CONSTRAINT [FK_Folders_Collections]
GO

-- ****************************************************************************************************
CREATE TABLE [dbo].[Orders](
	[Id] [nvarchar](36) NOT NULL,
	[Headers] [nvarchar](110) NOT NULL,
	[Url] [nvarchar](85) NOT NULL,
	[PreRequestScript] [nvarchar](50) NULL,
	[Method] [nvarchar](10) NOT NULL,
	[CollectionId] [nvarchar](36) NOT NULL,
	[DataMode] [nvarchar](10) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](570) NULL,
	[DescriptionFormat] [nvarchar](10) NULL,
	[Time] [bigint] NOT NULL,
	[Version] [int] NOT NULL,
	[Tests] [nvarchar](570) NOT NULL,
	[CurrentHelper] [nvarchar](10) NOT NULL,
	[IsFromCollection] [bit] NOT NULL,
	[FolderId] [nvarchar](36) NOT NULL,
	[RawModeData] [nvarchar](90) NOT NULL,
 CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Orders_Collections] FOREIGN KEY([CollectionId])
REFERENCES [dbo].[Collections] ([Id])
GO

ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Orders_Collections]
GO

ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Orders_Folders] FOREIGN KEY([FolderId])
REFERENCES [dbo].[Folders] ([Id])
GO

ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Orders_Folders]
GO

-- ****************************************************************************************************
CREATE TABLE [dbo].[Datas](
	[Id] [nvarchar](36) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[OrderId] [nvarchar](36) NOT NULL,
 CONSTRAINT [PK_Datas] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Datas]  WITH CHECK ADD  CONSTRAINT [FK_Datas_Orders] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Orders] ([Id])
GO

ALTER TABLE [dbo].[Datas] CHECK CONSTRAINT [FK_Datas_Orders]
GO

-- ****************************************************************************************************
CREATE TABLE [dbo].[HelperAttributes](
	[Id] [nvarchar](36) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[OrderId] [nvarchar](36) NOT NULL,
 CONSTRAINT [PK_HelperAttributes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[HelperAttributes]  WITH CHECK ADD  CONSTRAINT [FK_HelperAttributes_Orders] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Orders] ([Id])
GO

ALTER TABLE [dbo].[HelperAttributes] CHECK CONSTRAINT [FK_HelperAttributes_Orders]
GO

-- ****************************************************************************************************
CREATE TABLE [dbo].[PathVariables](
	[Id] [nvarchar](36) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[OrderId] [nvarchar](36) NOT NULL,
 CONSTRAINT [PK_PathVariables] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PathVariables]  WITH CHECK ADD  CONSTRAINT [FK_PathVariables_Orders] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Orders] ([Id])
GO

ALTER TABLE [dbo].[PathVariables] CHECK CONSTRAINT [FK_PathVariables_Orders]
GO

-- ****************************************************************************************************

CREATE TABLE [dbo].[Responses](
	[Id] [nvarchar](36) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[OrderId] [nvarchar](36) NOT NULL,
 CONSTRAINT [PK_Responses] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Responses]  WITH CHECK ADD  CONSTRAINT [FK_Responses_Orders] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Orders] ([Id])
GO

ALTER TABLE [dbo].[Responses] CHECK CONSTRAINT [FK_Responses_Orders]
GO
