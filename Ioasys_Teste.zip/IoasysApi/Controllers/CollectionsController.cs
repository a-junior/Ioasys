using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Data;
using IoasysApi.Models;

namespace IoasysApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CollectionsController : ControllerBase
    {
        private readonly ApiDBContext _context;

        public CollectionsController(ApiDBContext context) => _context = context;
        
        // GET api/collections
        [HttpGet]
        public ActionResult<IEnumerable<Collections>> GetCollections()
        {
            var objItem = _context.Collections;

            if (objItem == null)
            {
                return NotFound();
            }

            foreach (Collections objElem in objItem)
            {
                var lstFolders = _context.Folders.Where(e => e.CollectionId == objElem.Id).ToList<Folders>();

                foreach (Folders objElem2 in lstFolders)
                {
                    if (objElem.Id.Equals(objElem2.Id))
                    {
                        objElem.Folders.Add(new Folders() {Id = objElem2.Id, Name = objElem2.Name, Description = objElem2.Description, Owner = objElem2.Owner}); 
                    }
                }
            }
            
            return objItem;
        }

        // GET api/collections/5
        [HttpGet("{id}")]
        public ActionResult<Collections> GetCollectionItem(string id)
        {
            var objItem = _context.Collections.Find(id);
            
            if (objItem == null)
            {
                return NotFound();
            }

            objItem.Folders = _context.Folders.Where(e => e.CollectionId == id).ToList<Folders>();
            
            return objItem;
        }

        // GET api/collections/name/texto
        [HttpGet("name/{name}")]
        public ActionResult<IEnumerable<Collections>> GetCollectionsPorNome(string name)
        {
            var objItem = _context.Collections.Where(e => e.Name.Contains(name)).ToList<Collections>();

            if (objItem == null)
            {
                return NotFound();
            }

            return objItem;
        }

        // GET api/collections/tipo/texto { True / False }
        [HttpGet("tipo/{tipo}")]
        public ActionResult<IEnumerable<Collections>> GetCollectionsPorNome(bool tipo)
        {
            var objItem = _context.Collections.Where(e => e.Public == tipo).ToList<Collections>();
            
            if (objItem == null)
            {
                return NotFound();
            }

            return objItem;
        }
    }
}
