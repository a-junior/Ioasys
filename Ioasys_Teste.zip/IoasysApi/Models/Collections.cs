﻿using System;
using System.Collections.Generic;

namespace IoasysApi.Models
{
    public partial class Collections
    {
        public Collections()
        {
            Folders = new HashSet<Folders>();
            Requests = new HashSet<Orders>();
            Order = new List<Orders>();
        }

        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public long TimeStamp { get; set; }
        public int Owner { get; set; }
        public bool Public { get; set; }

        public virtual ICollection<Folders> Folders { get; set; }
        public virtual ICollection<Orders> Requests { get; set; }
        public virtual List<Orders> Order { get; set; }
    }
}
