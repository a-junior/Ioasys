﻿using System;
using System.Collections.Generic;

namespace IoasysApi.Models
{
    public partial class Orders
    {
        public Orders()
        {
            Datas = new HashSet<Datas>();
            HelperAttributes = new HashSet<HelperAttributes>();
            PathVariables = new HashSet<PathVariables>();
            Responses = new HashSet<Responses>();
        }

        public string Id { get; set; }
        public string Headers { get; set; }
        public string Url { get; set; }
        public string PreRequestScript { get; set; }
        public string Method { get; set; }
        public string CollectionId { get; set; }
        public string DataMode { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string DescriptionFormat { get; set; }
        public long Time { get; set; }
        public int Version { get; set; }
        public string Tests { get; set; }
        public string CurrentHelper { get; set; }
        public bool IsFromCollection { get; set; }
        public string FolderId { get; set; }
        public string RawModeData { get; set; }

        public virtual Collections Collection { get; set; }
        public virtual Folders Folder { get; set; }
        public virtual ICollection<Datas> Datas { get; set; }
        public virtual ICollection<HelperAttributes> HelperAttributes { get; set; }
        public virtual ICollection<PathVariables> PathVariables { get; set; }
        public virtual ICollection<Responses> Responses { get; set; }
    }
}
