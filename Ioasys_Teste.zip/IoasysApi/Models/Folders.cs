﻿using System;
using System.Collections.Generic;

namespace IoasysApi.Models
{
    public partial class Folders
    {
        public Folders()
        {
            Orders = new HashSet<Orders>();
        }

        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Owner { get; set; }
        public string CollectionId { get; set; }

        public virtual Collections Collection { get; set; }
        public virtual ICollection<Orders> Orders { get; set; }
    }
}
