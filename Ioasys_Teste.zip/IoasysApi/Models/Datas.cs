﻿using System;
using System.Collections.Generic;

namespace IoasysApi.Models
{
    public partial class Datas
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public string OrderId { get; set; }

        public virtual Orders Order { get; set; }
    }
}
