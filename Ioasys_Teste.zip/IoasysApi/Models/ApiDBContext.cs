﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace IoasysApi.Models
{
    public partial class ApiDBContext : DbContext
    {
        public ApiDBContext()
        {
        }

        public ApiDBContext(DbContextOptions<ApiDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Collections> Collections { get; set; }
        public virtual DbSet<Datas> Datas { get; set; }
        public virtual DbSet<Folders> Folders { get; set; }
        public virtual DbSet<HelperAttributes> HelperAttributes { get; set; }
        public virtual DbSet<Orders> Orders { get; set; }
        public virtual DbSet<PathVariables> PathVariables { get; set; }
        public virtual DbSet<Responses> Responses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=DESKTOP-GEUQ0CR\\SQLEXPRESS;Database=dbIoasys;Trusted_Connection=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Collections>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.Description).HasMaxLength(50);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Datas>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.OrderId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.Datas)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Datas_Orders");
            });

            modelBuilder.Entity<Folders>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.CollectionId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.Property(e => e.Description).HasMaxLength(50);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.Collection)
                    .WithMany(p => p.Folders)
                    .HasForeignKey(d => d.CollectionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Folders_Collections");
            });

            modelBuilder.Entity<HelperAttributes>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.OrderId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.HelperAttributes)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HelperAttributes_Orders");
            });

            modelBuilder.Entity<Orders>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.CollectionId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.Property(e => e.CurrentHelper)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.DataMode)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Description).HasMaxLength(570);

                entity.Property(e => e.DescriptionFormat).HasMaxLength(10);

                entity.Property(e => e.FolderId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.Property(e => e.Headers)
                    .IsRequired()
                    .HasMaxLength(110);

                entity.Property(e => e.Method)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.PreRequestScript).HasMaxLength(50);

                entity.Property(e => e.RawModeData)
                    .IsRequired()
                    .HasMaxLength(90);

                entity.Property(e => e.Tests)
                    .IsRequired()
                    .HasMaxLength(570);

                entity.Property(e => e.Url)
                    .IsRequired()
                    .HasMaxLength(85);

                entity.HasOne(d => d.Collection)
                    .WithMany(p => p.Requests)
                    .HasForeignKey(d => d.CollectionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Orders_Collections");

                entity.HasOne(d => d.Folder)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.FolderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Orders_Folders");
            });

            modelBuilder.Entity<PathVariables>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.OrderId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.PathVariables)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PathVariables_Orders");
            });

            modelBuilder.Entity<Responses>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.OrderId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.Responses)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Responses_Orders");
            });
        }
    }
}
